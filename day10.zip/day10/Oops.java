package day10;

import java.util.Scanner;

public class Oops {
	int id;
	String name;
	long phoneno = 2152515244l;
	int salary;

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		

		Oops emp1 = new Oops();
		
		emp1.id=21;

		{
			System.out.println("empolyee id"+emp1.id)  ;
			System.out.println(emp1.name = "surya");
			System.out.println("employee phone number :" + (emp1.phoneno = 55454216));
			System.out.println(emp1.salary = 35000);
		}

		Oops emp2 = new Oops();

		{
			System.out.println("employee id no :" + (emp2.id = 20));
			;
			System.out.println("employee name :" + (emp2.name = "santhosh"));
			System.out.println("employee phone number :" + (emp2.phoneno = 566415423));
			System.out.println("employee salary  :" + (emp2.salary = 45000));
		}

		Oops emp3 = new Oops();

		{
			System.out.println("employee id  :"+(emp3.id=45));
			
			System.out.println("employee name  :"+(emp3.name="vijay"));
			
			System.out.println("employee phone no  :"+(emp3.id=566142463));
			
			System.out.println("employee salary  :" + (emp3.id = 50000));
		}
		
		{

			Oops c=new Oops ();
				System.out.println("employee id  :");
				 c.id=sc.nextInt();
				System.out.println("employee name  :");
				 c.name=sc.next();
				System.out.println("employee phone no  :");
				 c.phoneno=sc.nextLong();
				System.out.println("employee salary  :");
				 c.salary=sc.nextInt();
				 
				 
				 System.out.println(c.id);
				 System.out.println(c.name);
				 System.out.println(c.phoneno);
				 System.out.println(c.salary);
				
		}

	}

}
