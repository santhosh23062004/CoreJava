package day10;

import java.util.Scanner;

public class Calculator {

	public void add(int num1, int num2) {
		System.out.println("addition :"+(num1 + num2));
	}

	public void subract(int num1, int num2) {
		System.out.println("subract :"+(num1 - num2));
	}

	public void multiply(int num1, int num2) {
		System.out.println("muliply"+(num1 * num2));
	}

	public void division(int num1, int num2) {
		System.out.println("division"+(num1 / num2));
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Calculator total = new Calculator();
		System.out.println("enter the number :");
		int num1 = sc.nextInt();
		System.out.println("enter the number :");
		int num2 = sc.nextInt();

		total.add(num1, num2);
		total.subract(num1, num2);
		total.multiply(num1, num2);
		total.division(num1, num2);

	}

}
