package day3;
import java.util.Scanner;
public class scanner {
	
	Scanner sc=new Scanner(System.in);
	
	{
		System.out.println("Enter the first number\t\t");
		int a=sc.nextInt();
		System.out.println("Enter the Second number\t\t");
		int b=sc.nextInt();
		System.out.println("add"+(a+b));
		System.out.println("sub"+(a-b));
		System.out.println("multiply"+(a*b));
		System.out.println("divison"+(a/b));
		System.out.println("modulus"+(a%b));
		
		
		
		
	}

}
